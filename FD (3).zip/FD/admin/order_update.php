<?php
include("../connection/connect.php");
error_reporting(0);
session_start();

if (strlen($_SESSION['user_id']) == 0) {
    header('location:../login.php');
} else {
    if (isset($_POST['update'])) {
        $form_id = $_GET['form_id'];
        $status = $_POST['status'];
        $remark = $_POST['remark'];
        $dispatch_time = $_POST['dispatch_time']; // Dispatch time input
        $delivery_time = $_POST['delivery_time']; // Delivery time input

        // Insert remark and status
        $query = mysqli_query($db, "INSERT INTO remark(frm_id, status, remark) VALUES('$form_id', '$status', '$remark')");
        
        // Update the users_orders table with status, dispatch, and delivery times
        $sql = mysqli_query($db, "UPDATE users_orders SET status='$status', dispatch_time='$dispatch_time', delivery_time='$delivery_time' WHERE o_id='$form_id'");
        
        echo "<script>alert('Order details updated successfully');</script>";
    }
}
?>
<script>
function f2() {
    window.close();
}
function f3() {
    window.print();
}
</script>
<head>
    <title>Order Update</title>
    <link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
    <style>
        table {
            width: 650px;
            margin: auto;
            margin-top: 50px;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: left;
        }
        th {
            background: #004684;
            color: white;
        }
    </style>
</head>
<body>
    <div style="margin-left:50px;">
        <form name="updateticket" id="updatecomplaint" method="post">
            <table>
                <tr>
                    <td><b>Form Number</b></td>
                    <td><?php echo htmlentities($_GET['form_id']); ?></td>
                </tr>
                <tr>
                    <td><b>Status</b></td>
                    <td>
                        <select name="status" required>
                            <option value="">Select Status</option>
                            <option value="in process">On the way</option>
                            <option value="closed">Delivered</option>
                            <option value="rejected">Cancelled</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td><b>Dispatch Time</b></td>
                    <td>
                        <input type="datetime-local" name="dispatch_time" required>
                    </td>
                </tr>
                <tr>
                    <td><b>Delivery Time</b></td>
                    <td>
                        <input type="datetime-local" name="delivery_time" required>
                    </td>
                </tr>
                <tr>
                    <td><b>Message</b></td>
                    <td><textarea name="remark" cols="50" rows="10" required></textarea></td>
                </tr>
                <tr>
                    <td><b>Action</b></td>
                    <td>
                        <input type="submit" name="update" class="btn btn-primary" value="Submit">
                        <input name="Submit2" type="button" class="btn btn-danger" value="Close this window" onClick="return f2();" />
                    </td>
                </tr>
            </table>
        </form>
    </div>
</body>
