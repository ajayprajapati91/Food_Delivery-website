<?php
include("connection/connect.php");

if (isset($_POST['order_id'])) {
    $order_id = $_POST['order_id'];
    
    // Fetch order details based on the order_id
    $query = "SELECT * FROM users_orders WHERE o_id='$order_id'";
    $result = mysqli_query($db, $query);
    $order = mysqli_fetch_assoc($result);

    if ($order) {
        $status = $order['status'];
        $order_time = $order['order_time']; // Assuming 'order_time' stores the order timestamp in "Y-m-d H:i:s" format

        // Ensure timezone consistency
        $timezone = new DateTimeZone('Asia/Kolkata'); 
        $current_time = new DateTime('now', $timezone);
        $order_datetime = new DateTime($order_time, $timezone);

        // Calculate the time difference in seconds
        $interval = $current_time->diff($order_datetime);
        $time_difference_in_seconds = ($interval->days * 24 * 60 * 60) + ($interval->h * 3600) + ($interval->i * 60) + $interval->s;
        $time_difference_in_minutes = $time_difference_in_seconds / 60;

        // Determine the updated status based on the time difference
        $updated_status = $status;
        if ($time_difference_in_minutes < 15 && ($status == '' || $status == 'NULL')) {
            $updated_status = 'Dispatch';
        } elseif ($time_difference_in_minutes >= 15 && $time_difference_in_minutes < 30 && $status != 'On the Way') {
            $updated_status = 'On the Way';
        } elseif ($time_difference_in_minutes >= 30 && $status != 'Delivered') {
            $updated_status = 'Delivered';
        } elseif ($status == '' || $status == 'NULL') {
            $updated_status = 'Cancelled';
        }

        // If the status has changed, update it in the database
        if ($updated_status !== $status) {
            $update_query = "UPDATE users_orders SET status='$updated_status' WHERE o_id='$order_id'";
            if (mysqli_query($db, $update_query)) {
                // Respond with the new status
                echo json_encode([
                    'status' => $updated_status,
                    'buttonClass' => strtolower(str_replace(' ', '-', $updated_status))
                ]);
            } else {
                echo json_encode(['status' => 'Error', 'buttonClass' => 'danger']);
            }
        }
    } else {
        echo json_encode(['status' => 'Error', 'buttonClass' => 'danger']);
    }
}
?>
