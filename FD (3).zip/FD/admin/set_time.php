<?php
include("../connection/connect.php");
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $dispatch_time = $_POST['dispatch_time'];
    $delivery_time = $_POST['delivery_time'];
    
    // Update the specific order with the set times
    $order_id = $_GET['order_id']; // Pass the order ID dynamically
    $query = "UPDATE users_orders 
              SET dispatch_time = '$dispatch_time', 
                  delivery_time = '$delivery_time' 
              WHERE o_id = '$order_id'";
    if (mysqli_query($db, $query)) {
        echo "Times set successfully!";
    } else {
        echo "Error: " . mysqli_error($db);
    }
}
?>
