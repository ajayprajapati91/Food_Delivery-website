 <footer class="footer" style="text-align: center;">Developed By Ajay Prajapati © 2024 - Online Food Ordering System Developer - <a href="#"></a> </footer>
 