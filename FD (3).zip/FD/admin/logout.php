                <!--  Author Name: Ajay-->
                <?php
session_start();
session_destroy();
$url = 'index.php';
header('Location: ' . $url);

?>
                <!--  Author Name: Ajay-->