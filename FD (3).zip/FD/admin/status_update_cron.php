<?php
// Include database connection
include("../connection/connect.php");  // Adjust path if necessary

// Check if the connection was successful
if (!$db) {
    echo "Connection failed: " . mysqli_connect_error();  // Show error message for debugging
    exit;
}

echo "Connected successfully!<br>";  // Check if connection was successful

// Fetch pending orders
$query = "SELECT * FROM users_orders WHERE status IN ('pending', 'in process')";
$result = mysqli_query($db, $query);

// Check if there are any pending orders
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $order_id = $row['o_id'];
        $current_status = $row['status'];

        // Logic for updating status
        if ($current_status == 'pending') {
            $new_status = 'in process'; // Update to 'in process'
        } elseif ($current_status == 'in process') {
            $new_status = 'closed'; // Update to 'closed'
        } else {
            continue; // Skip if status is already updated
        }

        // Use prepared statements to avoid SQL injection
        $update_query = "UPDATE users_orders SET status = ? WHERE o_id = ?";
        $stmt = mysqli_prepare($db, $update_query);

        // Bind parameters to the prepared statement
        mysqli_stmt_bind_param($stmt, "si", $new_status, $order_id);

        // Execute the prepared statement
        if (mysqli_stmt_execute($stmt)) {
            echo "Order ID $order_id status updated to $new_status successfully.<br>";
        } else {
            echo "Failed to update order ID $order_id: " . mysqli_error($db) . "<br>";
        }

        // Close the prepared statement
        mysqli_stmt_close($stmt);
    }
} else {
    echo "No pending orders to update.";
}

// Close the database connection
mysqli_close($db);
?>
