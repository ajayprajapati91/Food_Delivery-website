<?php
include("connection/connect.php");
error_reporting(0);
session_start();

if (empty($_SESSION['user_id'])) {
    header('location:login.php');
    exit();
}

function getStatusClass($status) {
    switch ($status) {
        case 'Dispatch':
            return 'info';
        case 'On the Way':
            return 'warning';
        case 'Delivered':
            return 'success';
        case 'Cancelled':
            return 'danger';
        default:
            return 'secondary';
    }
}

function calculateTimeDifferenceInMinutes($orderTime) {
    $currentTime = new DateTime();
    $orderDate = new DateTime($orderTime);
    $timeDifference = $currentTime->getTimestamp() - $orderDate->getTimestamp();
    return floor($timeDifference / 60); // Return time difference in minutes
}

if (isset($_POST['order_id']) && isset($_POST['new_status'])) {
    $order_id = $_POST['order_id'];
    $new_status = $_POST['new_status'];

    // Update order status in the database
    $updateQuery = "UPDATE users_orders SET status = '$new_status' WHERE o_id = '$order_id'";
    if (mysqli_query($db, $updateQuery)) {
        echo "Status updated to $new_status";
    } else {
        echo "Error updating status: " . mysqli_error($db);
    }
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>My Orders</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <style>
        .indent-small { margin-left: 5px; }
        .form-group.internal { margin-bottom: 0; }
        .panel-body { background: #e5e5e5; font: 600 15px "Open Sans", Arial, sans-serif; }
        label.control-label { font-weight: 600; color: #777; }
        table { width: 100%; }
        thead tr { background: #404040; color: white; }
        td { padding: 10px; border: 1px solid #ccc; text-align: left; font-size: 14px; }
    </style>
</head>

<body>
    <header id="header" class="header-scroll top-header headrom">
        <nav class="navbar navbar-dark">
            <div class="container">
                <a class="navbar-brand" href="index.php">
                    <img class="img-rounded" src="images/logo.png" alt="" width="18%">
                </a>
                <div class="collapse navbar-toggleable-md float-lg-right" id="mainNavbarCollapse">
                    <ul class="nav navbar-nav">
                        <li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
                        <li class="nav-item"><a class="nav-link active" href="restaurants.php">Restaurants</a></li>
                        <?php
                        if (empty($_SESSION["user_id"])) {
                            echo '<li class="nav-item"><a href="login.php" class="nav-link active">Login</a></li>
                                  <li class="nav-item"><a href="registration.php" class="nav-link active">Register</a></li>';
                        } else {
                            echo '<li class="nav-item"><a href="your_orders.php" class="nav-link active">My Orders</a></li>';
                            echo '<li class="nav-item"><a href="logout.php" class="nav-link active">Logout</a></li>';
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <div class="page-wrapper">
        <section class="restaurants-page">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="bg-gray">
                            <div class="row">
                                <table class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Item</th>
                                            <th>Quantity</th>
                                            <th>Price</th>
                                            <th>Status</th>
                                            <th>Date</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody id="order-table-body">
                                        <?php
                                        $query_res = mysqli_query($db, "SELECT * FROM users_orders WHERE u_id='" . $_SESSION['user_id'] . "'");

                                        if (mysqli_num_rows($query_res) == 0) {
                                            echo '<td colspan="6"><center>You have no orders placed yet.</center></td>';
                                        } else {
                                            while ($row = mysqli_fetch_assoc($query_res)) {
                                                $order_id = $row['o_id'];
                                                $status = $row['status'];
                                                $order_time = $row['order_time'];

                                                $timeDifference = calculateTimeDifferenceInMinutes($order_time);
                                                $updated_status = $status;

                                                if ($timeDifference < 10000 && (empty($status) || $status == 'NULL')) {
                                                    $updated_status = 'Dispatch';
                                                } elseif ($timeDifference >= 10000 && $timeDifference < 120000 && $updated_status !== 'On the Way' && $updated_status == 'Dispatch') {
                                                    $updated_status = 'On the Way';
                                                } elseif ($timeDifference >= 300000) {
                                                    $updated_status = 'Delivered';
                                                } else {
                                                    $updated_status = $status ?: 'Cancelled';
                                                }

                                                if ($updated_status !== $status) {
                                                    $update_query = "UPDATE users_orders SET status='$updated_status' WHERE o_id='$order_id'";
                                                    mysqli_query($db, $update_query);
                                                }
                                                ?>
                                                <tr id="order-<?php echo $order_id; ?>" data-order-time="<?php echo strtotime($order_time); ?>">
                                                    <td><?php echo $row['title']; ?></td>
                                                    <td><?php echo $row['quantity']; ?></td>
                                                    <td>Rs <?php echo $row['price']; ?></td>
                                                    <td>
                                                        <button type="button" class="btn btn-<?php echo getStatusClass($updated_status); ?>" id="status-<?php echo $order_id; ?>">
                                                            <?php echo $updated_status; ?>
                                                        </button>
                                                    </td>
                                                    <td><?php echo $row['date']; ?></td>
                                                    <td>
                                                        <a href="delete_orders.php?order_del=<?php echo $order_id; ?>" class="btn btn-danger btn-flat btn-addon btn-xs m-b-10">
                                                            <i class="fa fa-trash-o" style="font-size:16px"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                        <?php
                                            }
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php include "include/footer.php" ?>
    </div>

    <script src="js/jquery.min.js"></script>
    <script>
        // Function to calculate time difference in minutes
        function calculateTimeDifferenceInMinutes(orderTime) {
            const currentTime = new Date();
            const orderDate = new Date(orderTime * 1000);  // Convert timestamp to milliseconds
            const timeDifference = Math.floor((currentTime - orderDate) / 60000);  // Difference in minutes
            return timeDifference;
        }

        // Function to update order status
        function updateOrderStatus() {
            $('#order-table-body tr').each(function () {
                const orderId = $(this).attr('id').replace('order-', '');
                const orderTime = $(this).data('order-time');
                const statusButton = $(this).find('.order-status button');
                const currentStatus = statusButton.text().trim();

                const timeDifference = calculateTimeDifferenceInMinutes(orderTime);
                let newStatus = currentStatus;

                // Determine new status based on time difference
                if (timeDifference < 10000 && currentStatus !== 'Dispatch') {
                    newStatus = 'Dispatch';
                    statusButton.removeClass().addClass('btn btn-info');
                } else if (timeDifference >= 10000 && timeDifference < 120000 && currentStatus !== 'On the Way' && currentStatus == 'Dispatch' ) {
                    newStatus = 'On the Way';
                    statusButton.removeClass().addClass('btn btn-warning');
                } else if (timeDifference >= 300000 && currentStatus !== 'Dispatch' && currentStatus !== 'Delivered') {
                    newStatus = 'Delivered';
                    statusButton.removeClass().addClass('btn btn-success');
                } else if (timeDifference > 0 && currentStatus !== 'Cancelled') {
                    newStatus = 'Cancelled';
                    statusButton.removeClass().addClass('btn btn-danger');
                }

                // If the status is updated, make an AJAX request to update the database
                if (newStatus !== currentStatus) {
                    $.ajax({
                        url: '',
                        type: 'POST',
                        data: {
                            order_id: orderId,
                            new_status: newStatus
                        },
                        success: function(response) {
                            console.log('Order status updated:', response);
                        }
                    });
                }

                // Update the text of the status button
                statusButton.text(newStatus);
            });
        }

        // Run updateOrderStatus every minute to keep the status updated
        setInterval(updateOrderStatus, 60000);  // Update every 1 minute
        $(document).ready(function () {
            updateOrderStatus();  // Call it on page load to initialize the status
        });
    </script>
</body>
</html>




///
<!DOCTYPE html>
<html lang="en">
<?php
include("connection/connect.php");
error_reporting(0);
session_start();

if(empty($_SESSION['user_id'])) {
    header('location:login.php');
} else {
?>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="#">
    <title>My Orders</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <style type="text/css">
        .indent-small {
            margin-left: 5px;
        }

        .form-group.internal {
            margin-bottom: 0;
        }

        .panel-body {
            background: #e5e5e5;
            font: 600 15px "Open Sans", Arial, sans-serif;
        }

        label.control-label {
            font-weight: 600;
            color: #777;
        }

        table {
            width: 100%;
        }

        thead tr {
            background: #404040;
            color: white;
        }

        td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: left;
            font-size: 14px;
        }
    </style>
</head>

<body>
    <header id="header" class="header-scroll top-header headrom">
        <nav class="navbar navbar-dark">
            <div class="container">
                <a class="navbar-brand" href="index.php">
                    <img class="img-rounded" src="images/logo.png" alt="" width="18%">
                </a>
                <div class="collapse navbar-toggleable-md float-lg-right" id="mainNavbarCollapse">
                    <ul class="nav navbar-nav">
                        <li class="nav-item"> <a class="nav-link active" href="index.php">Home</a> </li>
                        <li class="nav-item"> <a class="nav-link active" href="restaurants.php">Restaurants</a> </li>
                        <?php
                        if (empty($_SESSION["user_id"])) {
                            echo '<li class="nav-item"><a href="login.php" class="nav-link active">Login</a></li>
                                  <li class="nav-item"><a href="registration.php" class="nav-link active">Register</a></li>';
                        } else {
                            echo '<li class="nav-item"><a href="your_orders.php" class="nav-link active">My Orders</a></li>';
                            echo '<li class="nav-item"><a href="logout.php" class="nav-link active">Logout</a></li>';
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <div class="page-wrapper">
        <section class="restaurants-page">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="bg-gray">
                            <div class="row">
                                <table class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Item</th>
                                            <th>Quantity</th>
                                            <th>Price</th>
                                            <th>Status</th>
                                            <th>Date</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody id="order-table-body">
                                        <?php 
                                        $query_res = mysqli_query($db, "SELECT * FROM users_orders WHERE u_id='" . $_SESSION['user_id'] . "'");
                                        
                                        if (!mysqli_num_rows($query_res) > 0) {
                                            echo '<td colspan="6"><center>You have no orders placed yet.</center></td>';
                                        } else {
                                            while ($row = mysqli_fetch_array($query_res)) {
                                                
                                        ?>
                                            <tr>
                                                <td> <?php echo $row['title']; ?></td>
                                                <td> <?php echo $row['quantity']; ?></td>
                                                <td>Rs <?php echo $row['price']; ?></td>
                                                <td>
                                                    <?php
                                                    $status = $row['status'];
                                                    
                                                    $order_time = $row['order_time'];
                                                    $current_time = date("Y-m-d H:i:s");
                                                    $earlier_timestamp = strtotime($order_time);
                                                    $current_timestamp = strtotime($current_time);
                                                    $time_difference = $current_timestamp - $earlier_timestamp;
                                                    $time_difference_in_minutes = $time_difference / 60000000;
                                                    echo "Time difference in minutes: " . $time_difference_in_minutes . " minutes<br>";
                                                    if ($time_difference_in_minutes < 2 && ($status == '' || $status == 'NULL')) {
                                                        echo '<button type="button" class="btn btn-info">Dispatch</button>';
                                                    } elseif($time_difference_in_minutes> 2 && $time_difference_in_minutes < 3 && $status != 'On the Way') {
                                                        echo '<button type="button" class="btn btn-warning">On The Way!</button>';
                                                    } elseif ($time_difference_in_minutes > 3 && $time_difference_in_minutes != null  && $status != 'Delivered') {
                                                        echo '<button type="button" class="btn btn-success">Delivered</button>';
                                                    } else {
                                                        echo '<button type="button" class="btn btn-danger">Cancelled</button>';
                                                    }
                                                    ?>
                                                    
                                                </td>
                                                <td> <?php echo $row['date']; ?></td>
                                                <td> <a href="delete_orders.php?order_del=<?php echo $row['o_id']; ?>" onclick="return confirm('Are you sure you want to cancel your order?');" class="btn btn-danger btn-flat btn-addon btn-xs m-b-10"><i class="fa fa-trash-o" style="font-size:16px"></i></a></td>
                                            </tr>
                                        <?php 
                                            }
                                        } 
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <?php include "include/footer.php" ?>
    </div>

    <script src="js/jquery.min.js"></script>
    <script>
        setInterval(function() {
            $.ajax({
                url: "update_order_status.php",
                method: "GET",
                success: function(data) {
                    $('#order-table-body').html(data);
                }
            });
        }, 30000); // Update every 30 seconds
    </script>
</body>

</html>

<?php
}
?>

<!-- PHP Script: update_order_status.php -->

