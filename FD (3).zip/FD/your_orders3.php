<?php
include("connection/connect.php");
error_reporting(0);
session_start();

if (empty($_SESSION['user_id'])) {
    header('location:login.php');
    exit();
}

// Handle AJAX request to update status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id']) && isset($_POST['new_status'])) {
    $order_id = intval($_POST['order_id']);
    $new_status = mysqli_real_escape_string($db, $_POST['new_status']);

    $update_query = "UPDATE users_orders SET status = '$new_status' WHERE o_id = $order_id";
    if (mysqli_query($db, $update_query)) {
        echo "Order ID $order_id updated to $new_status";
    } else {
        echo "Error: " . mysqli_error($db);
    }
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>My Orders</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <style>
        table { width: 100%; }
        thead tr { background: #404040; color: white; }
        td { padding: 10px; border: 1px solid #ccc; text-align: left; font-size: 14px; }
    </style>
</head>
<body>
<header id="header" class="header-scroll top-header headrom">
    <nav class="navbar navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <img class="img-rounded" src="images/logo.png" alt="" width="18%">
            </a>
            <div class="collapse navbar-toggleable-md float-lg-right" id="mainNavbarCollapse">
                <ul class="nav navbar-nav">
                    <li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link active" href="restaurants.php">Restaurants</a></li>
                    <?php
                    if (empty($_SESSION["user_id"])) {
                        echo '<li class="nav-item"><a href="login.php" class="nav-link active">Login</a></li>
                              <li class="nav-item"><a href="registration.php" class="nav-link active">Register</a></li>';
                    } else {
                        echo '<li class="nav-item"><a href="your_orders.php" class="nav-link active">My Orders</a></li>';
                        echo '<li class="nav-item"><a href="logout.php" class="nav-link active">Logout</a></li>';
                    }
                    ?>
                </ul>
            </div>
        </div>
    </nav>
</header>

<div class="page-wrapper">
    <section class="restaurants-page">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="bg-gray">
                        <div class="row">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>Item</th>
                                        <th>Quantity</th>
                                        <th>Price</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody id="order-table-body">
                                    <?php
                                    $query_res = mysqli_query($db, "SELECT * FROM users_orders WHERE u_id='" . $_SESSION['user_id'] . "'");

                                    if (mysqli_num_rows($query_res) == 0) {
                                        echo '<td colspan="6"><center>You have no orders placed yet.</center></td>';
                                    } else {
                                        while ($row = mysqli_fetch_assoc($query_res)) {
                                            $order_id = $row['o_id'];
                                            $status = $row['status'];
                                            $order_time = strtotime($row['order_time']);
                                            ?>
                                            <tr id="order-<?php echo $order_id; ?>" data-order-id="<?php echo $order_id; ?>" data-order-time="<?php echo $order_time; ?>" data-status="<?php echo $status; ?>">
                                                <td><?php echo $row['title']; ?></td>
                                                <td><?php echo $row['quantity']; ?></td>
                                                <td>Rs <?php echo $row['price']; ?></td>
                                                <td>
                                                    <span class="btn status-button" id="status-<?php echo $order_id; ?>">
                                                        <?php echo $status; ?>
                                                    </span>
                                                </td>
                                                <td><?php echo $row['date']; ?></td>
                                                <td>
                                                    <a href="delete_orders.php?order_del=<?php echo $order_id; ?>" class="btn btn-danger">
                                                        <i class="fa fa-trash-o"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                            <?php
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php include "include/footer.php" ?>
</div>

<script src="js/jquery.min.js"></script>
<script>
    function getStatusClass(status) {
        switch (status) {
            case 'Dispatched': return 'btn-info';
            case 'On the Way': return 'btn-warning';
            case 'Out for Delivery': return 'btn-primary';
            case 'Delivered': return 'btn-success';
            case 'Cancelled': return 'btn-danger';
            default: return 'btn-secondary';
        }
    }

    function getRandomStatus() {
        const statuses = ['Dispatched', 'On the Way', 'Out for Delivery', 'Delivered'];
        const randomIndex = Math.floor(Math.random() * statuses.length);
        return statuses[randomIndex];
    }

    function updateOrderStatus() {
        $("#order-table-body tr").each(function () {
            const orderRow = $(this);
            const orderId = orderRow.data("order-id");
            const statusButton = orderRow.find(".status-button");
            let currentStatus = statusButton.text().trim();

            // Get a random new status
            const newStatus = getRandomStatus();

            // Update status only if the status has changed
            if (newStatus !== currentStatus) {
                $.ajax({
                    url: '',
                    type: 'POST',
                    data: { order_id: orderId, new_status: newStatus },
                    success: function (response) {
                        console.log(response);
                        statusButton.text(newStatus);
                        statusButton.removeClass().addClass(`btn ${getStatusClass(newStatus)}`);
                    },
                    error: function (xhr, status, error) {
                        console.error("Error updating status:", error);
                    }
                });
            }
        });
    }

    $(document).ready(function () {
        updateOrderStatus();
        setInterval(updateOrderStatus, 60000);  // Update every 1 minute
    });
</script>
</body>
</html>
